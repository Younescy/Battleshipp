var indexSectionsWithContent =
{
  0: "bcdfghimnprsw",
  1: "bg",
  2: "gm",
  3: "cdfgimp",
  4: "bchnprs",
  5: "c",
  6: "bw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator"
};

