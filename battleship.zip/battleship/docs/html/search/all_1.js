var searchData=
[
  ['canplaceboat_4',['canPlaceBoat',['../game_8c.html#a8f419cdd14adf56bb18a6c323892ba1f',1,'canPlaceBoat(struct GameBoard *board, struct Boat *boat):&#160;game.c'],['../game_8h.html#a8f419cdd14adf56bb18a6c323892ba1f',1,'canPlaceBoat(struct GameBoard *board, struct Boat *boat):&#160;game.c']]],
  ['celltype_5',['CellType',['../game_8h.html#a268ae74e98bc01a0e35f5e215580bcb4',1,'game.h']]],
  ['checkvictory_6',['checkVictory',['../game_8c.html#a674e7f16c936b0ffa77367f8a9565d5e',1,'checkVictory(struct GameBoard *board):&#160;game.c'],['../game_8h.html#a674e7f16c936b0ffa77367f8a9565d5e',1,'checkVictory(struct GameBoard *board):&#160;game.c']]],
  ['col_7',['col',['../structBoat.html#a22a87ce4fe0d2fb3919b10283feae0c8',1,'Boat']]],
  ['computerboard_8',['computerBoard',['../structGame.html#afc84a97740fd88cdd05e65036092dfe3',1,'Game']]],
  ['computerboats_9',['computerBoats',['../structGame.html#ad5c9c3e62aee5cd470114bb3bb0e7d05',1,'Game']]],
  ['computerturn_10',['computerTurn',['../game_8c.html#af2eb2b76212bb9fee83c07feccea8e05',1,'computerTurn(struct Game *game):&#160;game.c'],['../game_8h.html#af2eb2b76212bb9fee83c07feccea8e05',1,'computerTurn(struct Game *game):&#160;game.c']]],
  ['createboat_11',['createBoat',['../game_8c.html#a44fdfe285a52f71199477f530ab4929d',1,'createBoat(int size, int row, int col, bool horizontal):&#160;game.c'],['../game_8h.html#a44fdfe285a52f71199477f530ab4929d',1,'createBoat(int size, int row, int col, bool horizontal):&#160;game.c']]],
  ['creategameboard_12',['createGameBoard',['../game_8c.html#a009a259f4567cbea48659d08e9b93d67',1,'createGameBoard(int size):&#160;game.c'],['../game_8h.html#a009a259f4567cbea48659d08e9b93d67',1,'createGameBoard(int size):&#160;game.c']]]
];
