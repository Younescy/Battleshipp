var searchData=
[
  ['board_0',['board',['../structGameBoard.html#a11fecfb8d60fce2d8323ca6e2d1adb27',1,'GameBoard']]],
  ['board_5fsize_1',['BOARD_SIZE',['../game_8c.html#aa7a2b8ea2c784a4ad8b58a3262bb4f07',1,'BOARD_SIZE():&#160;game.c'],['../game_8h.html#aa7a2b8ea2c784a4ad8b58a3262bb4f07',1,'BOARD_SIZE():&#160;game.c']]],
  ['boat_2',['Boat',['../structBoat.html',1,'']]],
  ['boat_3',['BOAT',['../game_8h.html#a268ae74e98bc01a0e35f5e215580bcb4a5fcfdc36f4798fb6ace9348a10f1e1b3',1,'game.h']]]
];
