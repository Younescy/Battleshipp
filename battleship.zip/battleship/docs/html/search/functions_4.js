var searchData=
[
  ['isboatalive_51',['isBoatAlive',['../game_8c.html#ab0328f5e48a2945f7f3f0b6c9a08e9c6',1,'isBoatAlive(struct Boat *boat):&#160;game.c'],['../game_8h.html#ab0328f5e48a2945f7f3f0b6c9a08e9c6',1,'isBoatAlive(struct Boat *boat):&#160;game.c']]]
];
